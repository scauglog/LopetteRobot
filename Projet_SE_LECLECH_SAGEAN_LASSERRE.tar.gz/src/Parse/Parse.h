/**
 * @File   Parse.h
 * @Author classerre, lleclech, rsagean
 *
 * Created on 27/11/2013, 16:51
 **/
#ifndef _PARSE_H_
#define _PARSE_H_

#include "../common.h"

void writeSerial(uint8_t i);
void parse(void);
#endif
